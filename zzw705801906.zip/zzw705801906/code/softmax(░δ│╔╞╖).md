

```python
# 数据处理包
import pandas as pd
import numpy as np

# 数据可视化包
import matplotlib.pyplot as plt

# 数据导入
def down_load_data():
    data_frame = pd.read_csv("D:\desktop\大数据学习\softmax数据\训练数据集.csv")

    x = data_frame.drop(['label', 'id'], axis=1)
    y = data_frame.label

    return x, y

# 代价函数
def loss_hanshu(x, y, rates):
    #  rates是10行20000列
    count = x.shape[0]  # 20000
    a = [i for i in range(count)]
    cost = (-1/count)*(np.sum(np.log(rates[y, a])))
    return cost

"""
   名称；softmax 函数（归一化指数函数）
   由来：二分类函数sigmoid的推广
   作用：将多分类的结果以概率的形式展现出来
   机理：传入z1,z2,z3，会计算e^z(i)，求累加，再分别除以累加，得到概率
   解释：（1）归一化：概率和为1   （2）指数：概率为非负数
"""

# softmax函数
def softmax(w, x):
    new_x = np.dot(w, x.transpose())  # 10行20000列
    ex = np.exp(new_x)  # 10行20000列

    #np.seterr(divide='ignore', invalid='ignore')
    row = new_x.shape[0]
    lie = new_x.shape[1]
    rates = np.zeros((row, lie))
    for i in range(lie):
        rates[:, i] = ex[:, i]/ex[:, i].sum(axis=0)  # 10行20000列
    return rates, ex

# 梯度下降法
def ti_du_xia_jiang(x, y):
    alaph = 0.000000001  # 设置参数
    lie = x.shape[1]  # 784
    row = x.shape[0]  # 20000

    w = np.zeros(([10,lie]))
    times = 10
    rates, ex = softmax(w, x)
    a = [i for i in range(row)]
    costs = np.zeros(times)
    for i in range(times):
        new_rates = rates[y, a]+1  # 10行20000列
        #for j in range(10):
        w = w + (alaph/lie)*(np.sum(np.dot(new_rates, x)))
        rates, ex = softmax(w, x)
        costs[i] = loss_hanshu(x, y, rates)
    print(ex)
    return x, w, costs, rates

x,y = down_load_data()

x, w, costs, rates = ti_du_xia_jiang(x, y)
plt.plot(range(len(costs)), costs)
plt.show()
dataframe_pred = x.copy()
dataframe_pred['True'] = y
dataframe_pred['pred'] = rates.argmax(axis=0)
print(dataframe_pred)

```


```python

```
